"""The styles part (word/styles.xml)."""

from __future__ import annotations

from collections.abc import Mapping

from wordgenx.ir import TABLE_CONDITIONS, Document, Style, StyleKind, TableCondition
from wordgenx.ooxml.parts.numbering import numbering_ids
from wordgenx.ooxml.parts.properties import (
    cell_properties,
    paragraph_properties,
    run_properties,
    table_properties,
)
from wordgenx.ooxml.schema_order import STYLE, ordered
from wordgenx.ooxml.style_names import UI_PRIORITY, is_builtin, stored_name, style_id
from wordgenx.ooxml.xml import E, Element, nsmap
from wordgenx.props import EmitContext


class StyleError(ValueError):
    """An invalid style definition or reference."""


# The four defaults every Word document has: default paragraph, character, table
# and numbering styles. Users may redefine Normal; the others are fixed.
_NORMAL = Style(StyleKind.PARAGRAPH, "Normal", based_on=None)


def _base_styles() -> list[Element]:
    return [
        E(
            "w:style",
            {"w:type": "character", "w:default": "1", "w:styleId": "DefaultParagraphFont"},
            E("w:name", {"w:val": "Default Paragraph Font"}),
            E("w:uiPriority", {"w:val": "1"}),
            E("w:semiHidden"),
            E("w:unhideWhenUsed"),
        ),
        E(
            "w:style",
            {"w:type": "table", "w:default": "1", "w:styleId": "TableNormal"},
            E("w:name", {"w:val": "Normal Table"}),
            E("w:uiPriority", {"w:val": "99"}),
            E("w:semiHidden"),
            E("w:unhideWhenUsed"),
            E(
                "w:tblPr",
                E("w:tblInd", {"w:w": "0", "w:type": "dxa"}),
                E(
                    "w:tblCellMar",
                    E("w:top", {"w:w": "0", "w:type": "dxa"}),
                    E("w:left", {"w:w": "108", "w:type": "dxa"}),
                    E("w:bottom", {"w:w": "0", "w:type": "dxa"}),
                    E("w:right", {"w:w": "108", "w:type": "dxa"}),
                ),
            ),
        ),
        E(
            "w:style",
            {"w:type": "numbering", "w:default": "1", "w:styleId": "NoList"},
            E("w:name", {"w:val": "No List"}),
            E("w:uiPriority", {"w:val": "99"}),
            E("w:semiHidden"),
            E("w:unhideWhenUsed"),
        ),
    ]


def resolve_styles(document: Document) -> dict[str, Style]:
    """Style ID -> style for all paragraph/character styles the document defines (incl. Normal)."""
    styles: dict[str, Style] = {"Normal": _NORMAL}
    seen: set[str] = set()
    for style in document.styles:
        sid = style_id(style.name)
        if sid in seen:
            raise StyleError(f"style {style.name!r} is defined twice (style ID {sid!r})")
        seen.add(sid)
        if sid == "Normal" and style.kind is not StyleKind.PARAGRAPH:
            raise StyleError("Normal must be a paragraph style")
        if sid in ("DefaultParagraphFont", "TableNormal", "NoList"):
            raise StyleError(f"{style.name!r} is a fixed default style and cannot be redefined")
        styles[sid] = style

    template = document.template
    for style in styles.values():
        for kind, ref in (("based-on", style.based_on), ("next", style.next)):
            if ref is None:
                continue
            target = styles.get(style_id(ref))
            if target is None and template is not None and (found := template.style(ref)):
                if found.kind != style.kind.value:
                    raise StyleError(
                        f"style {style.name!r}: {kind} style {ref!r} is a different kind"
                    )
                continue
            if target is None:
                raise StyleError(f"style {style.name!r}: {kind} style {ref!r} is not defined")
            if target.kind is not style.kind:
                raise StyleError(f"style {style.name!r}: {kind} style {ref!r} is a different kind")
        if style.link is not None:
            linked = styles.get(style_id(style.link))
            if linked is None and template is not None and template.style(style.link):
                continue
            if linked is None:
                raise StyleError(
                    f"style {style.name!r}: linked style {style.link!r} is not defined"
                )
            if linked.kind is style.kind:
                raise StyleError(f"style {style.name!r}: a linked style must be of the other kind")
    _check_cycles(styles)
    return styles


def _check_cycles(styles: dict[str, Style]) -> None:
    for start in styles:
        seen = {start}
        current = styles[start].based_on
        while current is not None:
            sid = style_id(current)
            if sid in seen:
                raise StyleError(f"style {styles[start].name!r} has a cyclic based-on chain")
            if sid not in styles:  # a template style
                break
            seen.add(sid)
            current = styles[sid].based_on


def _table_parts(style: Style, ctx: EmitContext) -> dict[str, Element | None]:
    """w:tblPr, w:tcPr of a table style; banding needs band sizes in w:tblPr."""
    kinds = {c.kind for c in style.conditions}
    bands: dict[str, Element] = {}
    if kinds & {"band1Horz", "band2Horz"}:
        bands["tblStyleRowBandSize"] = E("w:tblStyleRowBandSize", {"w:val": "1"})
    if kinds & {"band1Vert", "band2Vert"}:
        bands["tblStyleColBandSize"] = E("w:tblStyleColBandSize", {"w:val": "1"})
    return {
        "tblPr": table_properties(style.table, ctx, bands),
        "tcPr": cell_properties(style.cell, ctx),
    }


def _condition(condition: TableCondition, ctx: EmitContext) -> Element:
    """One w:tblStylePr: pPr, rPr, tcPr (schema order)."""
    return E(
        "w:tblStylePr",
        {"w:type": condition.kind},
        paragraph_properties(condition.paragraph, ctx),
        run_properties(condition.run, ctx),
        cell_properties(condition.cell, ctx),
    )


def _style(style: Style, sid: str, ctx: EmitContext, num_ids: Mapping[str, int]) -> Element:
    name = stored_name(style.name)
    attrs = {"w:type": style.kind.value, "w:styleId": sid}
    if sid == "Normal":
        attrs["w:default"] = "1"
    if not is_builtin(name):
        attrs["w:customStyle"] = "1"
    priority = style.ui_priority if style.ui_priority is not None else UI_PRIORITY.get(name)
    numbering = None
    if style.numbering is not None:
        numbering = (num_ids[style.numbering.name], style.numbering.level - 1)

    based_on = style.based_on
    if style.kind is StyleKind.TABLE and based_on is None:
        based_on = "Normal Table"
    children: dict[str, Element | None] = {
        "name": E("w:name", {"w:val": name}),
        "basedOn": E("w:basedOn", {"w:val": style_id(based_on)}) if based_on else None,
        "next": E("w:next", {"w:val": style_id(style.next)}) if style.next else None,
        "link": E("w:link", {"w:val": style_id(style.link)}) if style.link else None,
        "uiPriority": E("w:uiPriority", {"w:val": str(priority)}) if priority else None,
        "qFormat": E("w:qFormat") if style.quick_format else None,
        "pPr": paragraph_properties(style.paragraph, ctx, numbering=numbering),
        "rPr": run_properties(style.run, ctx),
    }
    if style.kind is StyleKind.TABLE:
        children.update(_table_parts(style, ctx))
    present = {key: value for key, value in children.items() if value is not None}
    order = {kind: i for i, kind in enumerate(TABLE_CONDITIONS)}
    conditions = sorted(style.conditions, key=lambda c: order[c.kind])
    return E(
        "w:style",
        attrs,
        *ordered(present, STYLE),
        *(_condition(condition, ctx) for condition in conditions),
    )


def styles_xml(document: Document, ctx: EmitContext, num_offset: int = 0) -> Element:
    styles = resolve_styles(document)
    rpr = run_properties(document.default_run, ctx)
    ppr = paragraph_properties(document.default_paragraph, ctx)
    doc_defaults = E(
        "w:docDefaults",
        E("w:rPrDefault", rpr) if rpr is not None else None,
        E("w:pPrDefault", ppr) if ppr is not None else None,
    )
    ids = numbering_ids(document.numbering, num_offset)
    normal = _style(styles.pop("Normal"), "Normal", ctx, ids)
    return E(
        "w:styles",
        doc_defaults,
        normal,
        *_base_styles(),
        *(_style(style, sid, ctx, ids) for sid, style in styles.items()),
        nsmap=nsmap("w"),
    )
