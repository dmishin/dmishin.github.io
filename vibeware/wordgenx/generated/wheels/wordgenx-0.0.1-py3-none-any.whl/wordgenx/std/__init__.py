"""The wordgenx standard library: macro files loaded with ``\\use{std:name}``.

Each module is a plain ``.wgx`` macro file in this package. It builds conveniences
Word has no native concept for out of Word primitives (tables, paragraphs, runs),
so documents stay idiomatic Word. Copy a module into your project to customise it.
"""
