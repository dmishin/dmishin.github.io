"""Math: the LaTeX subset (parser) and its OMML output (design §3.14)."""
