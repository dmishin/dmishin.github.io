"""wordgenx: a document markup language that compiles to native Word (.docx) documents."""

__version__ = "0.0.1"
